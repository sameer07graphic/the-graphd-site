import React from "react";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-[#800000] to-purple-900 text-white p-4">
      <header className="text-center py-10">
        <h1 className="text-5xl font-bold text-[#800000]">The Graph,D</h1>
        <p className="text-lg mt-2 text-gray-300">
          Social Media Post Design for Consultancies & More
        </p>
        <a
          href="https://www.facebook.com/thegraphd"
          target="_blank"
          rel="noopener noreferrer"
        >
          <button className="mt-4 bg-[#800000] hover:bg-red-700 text-white px-4 py-2 rounded">
            Visit Us on Facebook
          </button>
        </a>
      </header>

      <main className="grid gap-8 max-w-4xl mx-auto">
        <section className="bg-white text-black shadow-xl rounded-2xl p-6">
          <h2 className="text-2xl font-semibold mb-2">About Us</h2>
          <p>
            At The Graph,D, we specialize in creating stunning social media designs
            for consultants, brands, and businesses. From profile aesthetics to promotional
            visuals, we help you elevate your online presence and connect with your audience.
          </p>
        </section>

        <section className="bg-white text-black shadow-xl rounded-2xl p-6">
          <h2 className="text-2xl font-semibold mb-2">Gallery</h2>
          <p>Showcase of our latest designs coming soon. Stay tuned!</p>
        </section>

        <section className="bg-white text-black shadow-xl rounded-2xl p-6">
          <h2 className="text-2xl font-semibold mb-2">Contact</h2>
          <p>
            Want to collaborate? Message us on our Facebook page or email us at
            <a href="mailto:contact@thegraphd.com" className="text-purple-700 ml-1 underline">contact@thegraphd.com</a>
          </p>
        </section>
      </main>

      <footer className="text-center mt-10 text-sm text-gray-400">
        © 2025 The Graph,D. All rights reserved.
      </footer>
    </div>
  );
}
